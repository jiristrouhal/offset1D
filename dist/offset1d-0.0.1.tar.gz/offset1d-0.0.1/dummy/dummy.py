import src.getxy
import math


N = 50
values = [abs(0.5*math.sin(4*i/N*math.pi)) for i in range(N)]
data_on_circle = [(math.cos(2*k/N*math.pi), math.sin(2*k/N*math.pi), values[k]) for k in range(N)]
outline, outline_and_graph = src.getxy.surf_and_graph(data_on_circle)


import matplotlib.pyplot as plt
import matplotlib.scale as sc


fig, ax = plt.subplots()
ax.plot(*outline,'black')
ax.plot(*outline_and_graph,'blue')
ax.set_aspect('equal')
plt.show()
